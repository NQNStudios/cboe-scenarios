Sound Showcase Readme v.1.3.0

This is the second release of this utility.  I've added a lot, including this readme. Other 
additions include a small graphics file, more Logical Combinations, and the Sound String 
Generation Laboratory.

I also changed the alignment of the sounds in the Buttons Galore rooms so that it is easier to 
navigate them in order.  Portals are auto staircases for easier navigation as well. (After waiting 
for the first 10-20 teleporting graphics and sounds I decided it best to bypass this in favor of 
ease.)

In the Generation Lab you can choose up to ten sounds to play in a row be they the same or 
different.  Set-up takes a significant bit of time but it sure beats entering it into the editor, 
quiting the editor, starting the game, and fighting through to the place where you have it set up.

Most of the scenarios that I've played really lack in the use of sounds and I hope that this 
utility will open the way for more designers to choose to use sound to enhance their games.

If you have any questions, comments, or bug reports, please send them to me at 
tracihedlund@charter.net.