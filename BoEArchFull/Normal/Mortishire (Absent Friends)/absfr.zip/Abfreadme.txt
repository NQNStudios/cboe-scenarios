Ref  : Blades of Exile Scenario "Absent Friends"
1/11/2000
This scenario has been tested on PC using Win95, and has NOT been externally Beta tested.
I therefore have no idea how it will perform on a Mac or other operating system.
This chance was taken in order to submit it for the Scenario Competition. In the event of any 
problems,please let me know and I will ensure it is repaired, or recalled if it is that bad!
Contact at gill.whitehurst@virgin.net

Suggested party level: New party
Hint:Talk to everybody about everything.
The plot is linear, the objective being to tell a story, so things should follow on neatly. Without external
testing it may not, so please contact me if anything odd happens. Playing time is about 3-4 hours.

Storyline
The party is taking a well earned rest after years of constant duty. They have recently lost friends, missing in 
action and presumed to be dead. In their quest for some peace and quiet they discover a powerful threat to
both the Empire, and its small neighbouring Republic in Mortishire.