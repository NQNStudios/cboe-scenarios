Kill Yourself, Win Prize
by Terror's Martyr

A gripping, philosophical metanarrative about dying to earn the wages of capitalism, KYWP has been hailed by porn critics and Babylonian deities alike as being breathtaking, monumental, and marked by a distinct lack of boobage.

This scenario is for any level, although is best suited for a party coming out of a Creator scenario, as the party's motive will most certainly be heightened.

Remember to rate this scenario at Spiderweb and The Lyceum, or mad ticks will fire out of my nipples and eat your grandparents.