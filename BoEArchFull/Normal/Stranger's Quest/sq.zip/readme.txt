Hi!

This scenario is my first effort. I hope you like it.

One thing to keep in mind is to talk to everyone, and read everything.  This scenario has several talking puzzles. Also, don't attack anything unless it attacks you first, because some of the dungeons have friendly characters.

If you have suggestions or corrections (evenm typos) send them to Benacks@union.edu.  Please have the subject start with the word blades so I can pick them out easy.
