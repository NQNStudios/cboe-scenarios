Inn of Blades
by Terror's Martyr
<terrorsmartyr@wi.rr.com>

The Inn of Blades is a scenario in which members of the Blades of Exile Community are placed into a scenario as personalities.  Some are enemies, some are allies, some are neutral, all should be interesting.
The Inn of Blades is not a town-only scenario with mere exploration.  It has many interesting sidequests and missions for you to complete.  Solve a murder, watch a movie, save the port of the Inn of Blades from destruction, and visit another universe!

The files included:

bladeinn.exs
This is the scenario itself.  Move it into the Blades of Exile Scenarios folder.
bladeinn.gif
This is the .gif file with the graphics for the Inn of Blades.
Windows: Use a common Painting application like Photoshop or even MS paint and convert it into a .bmp and move the bladeinn.bmp into the Scenarios folder with bladeinn.exs
Mac: Open the .gif file in any painting or viewing application, copy the entire document and create a file in ResEdit called bladeinn.meg and place it in the same folder as bladeinn.exs and paste the selection into Res Edit.  Open the graphics resource section you just created and select the selection you just pasted.  Hit Command+I and change the number at the top field into 1.
readme.txt
This is what you're reading now!

I would like to thank some people...
The people who submitted themselves to the Inn of Blades:
DragynBob, SunSlayer, Brett Bixler, Tigrene, Frahhamn, Lt. Sullust, Mr. Meanor, Urchin, TurtleWhipper, Apocalypse, Djur, L'kae, Ryan, Dahak, Flameball, Drakefyre and The Minstrel
The graphical artists:
Tim Farland, L'kae, Frahhamn, Istara, Brett Bixler, The Minstrel, Ryan Phelps, Aceron and Alcritas
The beta-testers:
Drakefyre, L'kae, Ryan

Thank you for downloading!  If you have any questions, you may contact me at my email above, at the Spiderweb Boards, or at the Lyceum Boards.  Spiderweb Boards reccomended.  Enjoy!

-Terror's Martyr