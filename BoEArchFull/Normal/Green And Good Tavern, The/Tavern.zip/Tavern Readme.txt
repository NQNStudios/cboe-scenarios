The Green and Good Tavern 

          A scenario by Kattana'ver Reaper(Dylan Hadd)

This scenario is for begginer level parties and is balenced specificly for the "cats" party enclosed with the scenario. depending on how many goblins you wan't to kill this level should take between 2 and 48 hours to complete and should raise you party to between level 3 and 15. Also the "cats" party has been edited, i have given the items and spells, removed some spells and given them extra experience. If you feel like playing the scenario with a higher level party it should still prove enjoyable and challenging.

Ps; For added fun don't forget to use summoning spells(summon host, weak summoning, ect...)

If you have any questions, coments, or complaints contact me at; 
Kattana_@hotmail.com

Thanks to the many graphic artist who made theis goblin extraveganza possible.

Motrax; the 3 nephil, goblin flinger

Paul Henderson; goblin crossbowmen,

Yakshini; goblin wolf rider, 

Aceron; goblin high priest, goblin warrior, goblin special forces, 
large bed,

HYZ; goblin wizard, 

Relhan; all of the orcs,

Sir Robin; goblin high guard,

Jon Richards; adobe fort, fences, 

DRKDRAXIS; grey fort,

spiderweb; pelt, meat, other meat, apples, pears, fish

Tim Farland; The lions, razorback bear, fire place, harry,

Greg Hoyle; goblin lord,

Shawn Lonergan; catress, arvest, 

Birdy; forest demon, glade guard, vine golem, moss horse, goblin 
mutant, goblin zombie, horned bear, stripped bear, analope, deer, 
cardinal, the masked goblin, 

Elvin Winleaf; water brazier,

Ireland; drain, bookself, alternative dresser, fountain,

Shawn Lonergan; dragon item set, 

Gil Glorion; keg, target, armor rack, wepon rack, warrior armor, mace, vermin hunter, 

Dante; spiner, shriuken, spiked bow, mail coif, gauntlets, horned helm, whip,

Adam Hoffman; forest dragon, tiger, bow, inferno, ice, shadow, 

Robin Seneka; baby rabbit,

The Good Reverend; rabbit, 

Kattana; Woman in red(edited from a graphic by Tim Farland), couger face, sheep face, Syreth spider face, syreth spider, cascaden, the butcher, bob, kaziganthi,

There are some graphics whos creator i could not find, if you see one of your graphics and are not being given credit for me tell me and i will update this readme.



Spoiler Below ===============================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================

Q; My money keeps getting stolen in the tavern, can i stop this?

A; Yes, their are 3 thugs in the tavern if you talk to them and then kill them ALL your money won't be stolen anymore.



Q; HOw do i get past the lake?

A; Go fishing utill you catch a trophy lake trout(the rarest fish) then search the caves to the west where the road ends.



Q; Do i need to fight my way through all of the bear caves?


A; No, But some may be interesting.


Q; i Caught a trophy lake trout and went in the caves but i still can't find a way past.

A; you have to go swimming, and than i cave will appear.