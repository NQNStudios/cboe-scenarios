THE NEPHILS' DEFENSE by Bain-Ihrno
Scenario Readme File

  I originally planned for this scenario to stay
unreleased, as The Creator give a "HARSH" beta report
which made the scenario look horrible. However, 
Creator and Gizmo BEGGED for the release of this
scenario, Creator convinced me, and I decided my
only choice now is to release the scenario.

Moral of the story: Don't expect this to be a good
scenario.

   Anyway, in this scenario, you play as a highly-respected
Nephilim archer named Crawlin. You live on an island
split into two halves by artificial mountains created
by Nephil wizards. Why? Two tribes of Nephilim have
had disagreements with each other, and they are split up.

But the other tribe suddenly attacked you, and it is up
to you to find out why and stop them! Enjoy!

- - - - - - - - - - - - - -
General Notes and Tips:

1. Please try to imagine that everyone here is speaking
in the Nephilim language. I only used English so that
you can understand what everyone is saying.

2. This scenario uses a pre-fab party (of course.) If 
the file doesn't work for you, you will need to use the
stats listed below to make Crawlin.

3. This scenario HAS A TIME LIMIT! There's only two side
quests, but you will need to play fast if you try to
undertake them both.

4. If you open up the graphics, you may notice
some pink lines. That's where some graphics were that
I decided not to use.

5. If there's a moldy wall in your way, ATTACK IT to bring it down. 
You have no magic in this game. Unfortunate, huh?

6. DO NOT and I mean DO NOT go to the checkpoint until
you are well equipped! The battles are tough and there is
very little hospitality for you beyond that point!

7. Always search containers that you see near you. There's
usually something nice there...

8. If you see an evil altar, always try to sanctify it.
There could be something useful...

- - - - - - - - - - - - - -

To Install this scenario:

PC USERS:

1. Move DEFENEPH.EXS and DEFENEPH.BMP into the 
Bladscen folder. 

2. Move CRAWLPC.SAV into the Bladexil folder. 

3. Load BOE, and load CRAWLIN.SAV up.

4. Click 'Custom Scenarios' and pick it from
the scenarios menu. Enjoy!

MAC USERS:

1. You will need to create a .MEG file. See Spiderweb's
site if you need any help with this.

2. Move DEFENEPH.EXS and DEFENEPH.MEG (once it's made) 
into the Bladscen folder. 

3. Use the stats to create Crawlin, and name it 
CRAWMAC.SAV

4. Move CRAWMAC.SAV into the Bladexil folder.

5. Load BOE and load up CRAWMAC.SAV.

6. Click 'custom scenarios' and pick it from the scenarios
menu. Enjoy!

- - - - - - - - - - - - - -

SCENARIO CREDITS:

Beta Testers:

-That's what you're doing now. Once you send a beta
report, your name will appear here in the final release.

Graphical Artists:

- Shawn Lonergan (Nephil Khazi, Nephil Elite, Nephil Attacker, Draconian Graphic)
- Shyguy (Nephil Lord, Dirt Path)
- Birdy (Goblin King)
- DRK DRAXIS (Wooden walls/floors)

And most importantly...

- Brett Bixler (Jungle Graphics) - seriously,
without them, I never would have even thought of making
this scenario.

I did the 'Alligator' graphic myself. Feel free to use
any graphics used here, as long as appropriate credit
is given.

Innovations:

-The Creator (Frame Animation, Read Book feature)
-Andres Gonzales (Attacking Terrain thing)
-Khoth (Gem Puzzle)
-Stareye (Special Spells)

Other:

-Skyle, for the Alternative Bladbase, which was used for
this scenario. (There. Happy, Drizzt?)

-The Creator, for making Deadly Goblins (not telling 'ya
why that's imporant - play the scenario)

- - - - - - - - - - - - - -
KNOWN BUGS:

- In the two outdoor encounters with the Alligators,
spots of cave floor appear. I'm too lazy to fix this.
Open this up in the editor to find out why;)

- - - - - - - - - - - - - -

So, are you stuck in this scenario? Have some praise
or critism? Something else entirely? 

E-mail me at: bihrno@yahoo.com

If you are REALLY stuck (though I doubt you will be), 
I will have a walkthrough of this scenario available.
If you want it, email me at the above adress.

- - - - - - - - - - - - - -
Enjoy the game, 

Bain-Ihrno



