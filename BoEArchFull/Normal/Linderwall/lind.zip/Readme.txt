This is my first scenario, and thank you for playing it. It's relatively short and small; I
played through it in about fortyfive minutes using the premade party that comes with Blades
of Exile. 

Credits for the graphics are as follows:
The blue dwarf is by Relhan.
The grey one is by Aceron.
The dragon skeleton is originally by Relhan, modified by me.
The double bed is by Aceron.
The musician is by DrkDraxis.
I don't know who drew the gravestone, the firepit on grass, or the stairs and windows.
Luz Piazuelo drew the tomb.
Pernandle, the cracked wall and floor, Herdinand and his dialogue picture, all the ghosts, the chair, and the fields were modified or drawn by me. The originals that I modified are all from Spiderweb Software.

"Smead", as in Borvacious, sounds like "stead" or "mead", not like "smeed".