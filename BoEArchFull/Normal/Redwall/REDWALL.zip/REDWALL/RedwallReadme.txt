Redwall: Prologue
Released August 2006
Traci Hedlund aka Gizmo
traci.hedlund@sbcglobal.net (primary)
tracihedlund@yahoo.com

Thank you for downloading my first scenario Redwall: Prologue.  It is
 based on the novel by Brian Jaques and is just an introduction to life at
 Redwall.  Fair warning, life at the Abbey may be peaceful but it is not
neccessarily easy.  

CREDITS
------------------
Beta-Testers include Bain-Ihrno on PC and Arachnid on MAC who
 graciously made the .sit files and contents.

Most of the custom graphics are my own, some are adapted from
 media.  The mural is from the cover of one of the Redwall editions.

The Abbey walls and stairs were adapted from Relhan, the windows
 from Jon Richards and Paul Henderson.

The red rug is Rabbitlords, the wood floor(used in haycart)is by
 Luz, and the crops by Haneda.

The fruit tree and animated water fountain were adapted from Shyguy.  
The barn wall(used as ramp to bell in bell tower) and flowers in vase
 are his also.

A few other adapted graphics made it to the graphic sheet but not to the
 scenario so honerable mention go to Drk Draxis for the grate, Elvin 
Windleaf for the water basin, Milu for the staircase, Aceron for the
 extra large bed, and Relhan for the sconce, shackles, and display case.

If you have any questions, bug-reports, or get stuck feel free to e-mail
 me at traci.hedlund@sbcglobal.net, tracihedlund@yahoo.com, or get
 my attention at either the Spiderweb forum or the Lyceum.

HOW TO MAKE MATTHIAS
----------------------------------
If for some reason the pre-fab party doesn't work for you, use these
 instructions to make your own.

Make a new party.
Save it as redwall.sav
Open it with the PCeditor.
Give the first character the following skills:
  Health: 20
  Strength: 5
  Dexterity: 4
  Intelligence: 8
  Edged Weapons: 4
  Pole Weapons: 3
  Thrown Missiles: 3
  Defense: 2
  Luck: 1
  Everything else at zero.
*Note: Skills don't really matter much in this scenario but they are the
 basis for future Redwall scenarios. Don't sweat them if you don't want.
 The future scenarios may never be made.
Give character these traits:
  Woodsman
  Good Constitution
  (no bad traits)
*Again this is just for show.
Take away all spells.
*There is no magic.
--**IMPORTANT**--
Change food to 20 and gold to 18.  Don't worry, it will be more then
 enough.
When you open the scenario for the first time in the game move one 
space then change the first characters name to Matthias and change the
 graphic to the brown robed monk with staff. (Top row, third from the
 left.) Delete the other PC's so they don't eat your food.
If you want perfection, before you delete them change their names to:
2.of
3.Redwall
4.is now
5.at
6.peace
Exit out of scenario and save.  Then save a backup so you can start
fresh easily if need be.


