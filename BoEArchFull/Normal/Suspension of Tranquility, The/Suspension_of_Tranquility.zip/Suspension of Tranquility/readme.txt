Suspension Of Tranqulity" Information

	I. Requirements 
		To run this scenario, you will need the registered vesion of Blades of Exile, since it is a custom scenario,
		developed Eric Jensen, and me(Sean Rea). Just pop it into the scenario folder, run Blades, and choose it from 
		the custom scenario menu.
	
	II. Description
		 While taking a brief break from adventuring, you recieve word of a vessel which has landed, unmanned, near 
		 Klaun. Obviously, you accept the offer and find a strange item cult, which is the cult you dealt with in
		 Exile 3. 
		 
	III. Hints
		  
		  1.) Why can't I cross the mountains? You probably need some skis. Ask around in Klaun.
		  2.) Why can't I get into the thief hideout? You'll need a ID pin. Find the Dungeon Of Adalome.
		 
		 These would be the 2 main problems you might have. There are others, but I'm not helping you discover the
		 answers to them. You can, however, always email me.
		 
	IV. Credits!
		
		There are several people who helped make this possible, and they are:
		
		Beta Testing & Plot Development: Eric 'Necromancer' Jensen
		Beta Testing:                    Tarl Roger "Never let them know how much you're improvising" Kudrick                   
            Beta Testing:                    Geoff "Insanity is relative" Embree
        
    V. Contact Information
    
        Need to contact me? Email me at <srea@dnc.net> or visit <http://www.dnc.net/users/bmsnrea/boe/index.html> for 
        more info and ratings this scenario has earned.
