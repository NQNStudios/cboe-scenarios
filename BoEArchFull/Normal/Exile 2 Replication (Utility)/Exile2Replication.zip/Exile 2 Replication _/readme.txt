Thank you for downloading my replication project! This scenario is a hopefully complete terrain replication of all the 'Exile II, Chapter 1' towns and dungeons in a Blades of Exile format, so that you can use these towns in a BoE scenario setting. PLEASE NOTE THAT THIS IS JUST A TERRAIN REPLICATION! THERE ARE NO MONSTERS AND HARDLY ANY SPECIALS IN THIS SCENARIO! 
This scenario should not be opened in Blades of Exile, because your party will not be able to go anywhere. There is virtually nothing in the outdoors section (to be replicated later). Use the Scenario Editor! If you do decide to use these towns in a scenario, please let me know via e-mail (darobinbot@netscape.net). If you notice anything I might have missed during the replication process, please tell me, again, via e-mail. 
Anyway, that's about it. I hope you can put these to good use!
--Robinator

Town List
Town 0--Fort Draco-----------Medium
Town 1--Fort Ganrick---------Small
Town 2--Under Fort Draco-----Small (Accessible only through Fort Draco)
Town 3--Spider Cave----------Medium
Town 4--Tiny Slith Fort-------Small
Town 5--Swampy Cave--------Small
Town 6--Solberg's Tower------Small
Town 7--Clearing-------------Small
Town 8--Formello------------Large
Town 9--Isolated Home--------Small (Accessible only with 'Flight' spell)
Town 10-Cave of Motrax-------Medium
Town 11-Ruined Town---------Small (Accessible only through Formello)
Town 12-Island Hut-----------Small (Accessible only through Formello / boat needed)
Town 13-Lizard Lair----------Small
Town 14-Lizard Lair (L2)------Small (Accessible only through Lizard Lair)
Town 15-Little Vale----------Small
Town 16-Gunston Homestead---Small
Town 17-Hidden Nephilim Cave-Small (In outdoor secret passage directly north of Nephilim Castle)
Town 18-Brigand Lair (L2)-----Small (Accessible only through Verdant Valley)
Town 19-Aranea Web----------Medium
Town 20-Blasted Ruins--------Medium
Town 21-Nephilim Castle------Large
Town 22-Verdant Valley-------Large
Town 23-Fiery Pit-------------Small (Accessible only through Verdant Valley)

P.S. Does anyone think an Exile replication contest at the Lyceum would be fun?