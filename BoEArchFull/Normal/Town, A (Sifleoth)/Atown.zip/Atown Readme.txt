The Town of Sifleoth; readme... this scenario contains only a bitmap file and a gif file so if you have a mac you will have to make your own graphics file for this scenario using the gif image. This scenario is for very high level parties(the highest you can get your hands on) and should take roughly 1-2 days to complete.
This is a lenier scenario and should play through rather quickly as mentioned before. if you are at any point unsure what to do a good rule of thumb is to EXPLORE there is barely a single square of terrain that cant be seen or gotten to. and you can't finish the scenario
unless you explore every last accessible square. if you explore the scenario and are still stuck you can contact me at KATTANA_@HOTMAIL.COM 

This scenario uses many custom graphics and i would like to thank all of the various artists however I don't remember who's is who's so if you would like to be given specific credit for any of the graphics i'll gladly abblige if you'd contact me with your name and the graphics you want credit for.
This scenario is very small and it uses a town only engine and has only 5 towns( although you can leave the town and go outdoors the outdoors is not an active part of the scenario.

If you have any other questions contact me at KATTANA_@HOTMAIL.COM and I will add the question to the list of frequently asked ones below.











Fequently asked questions below; possible spoiler
=======================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================

Q; What do ioun stones do?/ wand of manna

A; Each color raises a different stat by 1 and each works only once.
    Color ---- Stat
     Clear     luck
     Black     assasination
     Red       disarm traps
     Green     poison
     Blue      lockpicks
     Yellow    alchemy

     The wand of manna gives you 5 food and can be used 10 times

Q; How do i enter locked the rooms in the second story of the tavern

A; The one closest to the door can be open by looking at the door and using the small key you get from kyrothen. the other doors get be opened by looking at them and using the tavern owners key, this key can be gotten only when the tavern owner is killed.


MORE TO COME.......