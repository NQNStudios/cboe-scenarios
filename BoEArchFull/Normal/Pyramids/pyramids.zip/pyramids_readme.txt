R E A D  M E : P y r a m i d s (v 1.0.1)

This is a scenario created for the 2nd short scenario competition, where a scenario has to be created in one month. I have not been able to test the scenario extensively.

This file should contain the pyramids.exs file, the pyramids.bmp file, the pyramids.meg file, and this read me.

Custom graphics are integral to this scenario. If, as soon as you start, you are not in a grove of palm trees with sand as ground, then you need to make sure that the graphics file pyramids.meg or pyramids.bmp is in the scenario folder, and able to be opened.

You will also find this scenario impossible if you do not have the priest spell 'move mountains' - but, as this is a base level spell, it should be OK.

The scenario is for a high level party, and works very well with a single-PC party. It is of PG rating (it does involve the grave robbing of a pyramid).

Any comments, suggestions or (I hope not) problems with the scenario will always be welcomed, my email address is:

juerow@dial.pipex.com

Many thanks for downloading my scenario - I hope you enjoy it,

Juliet
--------------------------------------
Custom Graphics:
I have not created all the graphics in this scenario. In fact, the set of pyramid wall graphics I downloaded kind of inspired the whole scenario.

The pyramid wall graphics were created by Drkdra (I created most of the pictures on pyramid wall graphics though).

The water elemental monster graphic, the scorpion graphic, the red whirlwind graphic and the pyramid town graphic were not created by me.

All other custom graphics, including the tent wall set, were created by me.
--------------------------------------
Update to version 1.0.1:
Some specials inside the pyramid have been re-programmed, and all work for all possible paths through the pyramid.

Many thanks for Ryan Phelps, and Brett Bixler for pointing out the problems inside the pyramid.