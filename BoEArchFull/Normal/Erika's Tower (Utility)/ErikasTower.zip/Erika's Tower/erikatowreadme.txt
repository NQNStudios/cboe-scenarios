Erika's Tower:
------------------

An Utility Scenario by: S.M Adventurer

Introduction:

This is my remake of Erika's Tower from Exile 3. It may not look exactly the same but's that
just because of the many Blades of Exile limits. Some rooms may look smaller or bigger or might
have been moved.

Important Details:

- Erika has a  personality set. It's not really that great right now, but feel free to modify
it as you please.

- Be sure not to erase the sign with my name credit in Erika's Tower, near the southern
enterance of the tower.

- Be sure to credit me if you do decide to use Erika's Tower in your scenario.

If you wish to contact me, email me at: srmboe2@yahoo.com