   You awoke this morning in the Abbotsfield Jail with the captain of the town guards glaring down at you. It seems that  your party drank a bit too much ale and made a mess of the Ogre's Breath Tavern. This is your hometown and it's expected that you'll make reparations. 

   And so begins our story an epic tale of betrayal, berserk farm animals and ultimately redemption.

Thanks for downloading my scenario,

I've included a hint file, a map and some custom graphics. Put the graphics in the Bladscen directory with .exs file. Things will look weird without them. If you have any questions email me at alx149@earthlink.net. Enjoy

                       						Alex Jackson


