Echoes: Combat/Skirmish (?)
by Terror's Martyr
----

Files Included:
combat.exs- The scenario file.  Place in the BLADSCEN/Blades of Exile Scenarios folder.
combat.meg.sit- The graphics file for Mac users, stuffed.  Unstuff the file and place the newly created file in the Blades of Exile Scenarios folder.
combat.gif- The graphics file for PC users, in GIF format.  Open the file in any painting application (MSPaint will do), save it as a BMP file, and move it into the BLADSCEN folder.

----

Q: What the hell is this?
A: It's a full-screen frame animation I made in less than 6 hours in a rush towards the Omega contest deadline.  I did it more to test it out than actually make something worth watching.

Q: Well it's obvious that it's not worth watching, but why do you switch titles?
A: Again, it was made in less than 6 hours, and was rushed for the combat deadline.  I'd fix it up if there was anything worth fixing up, but I never really expected to make anything impressive out of this thing.

Q: This makes no sense.
A: Don't worry, you aren't missing out on much.  The only point to *this* scenario is that Illithids are waging a war, and if you hadn't picked this up from the other Echoes scenarios so far, then...  ...play the other Echoes scenarios. -_-;

Q: Was this even beta-tested?
A: I'm telling you, I made this thing in six hours!  No!  Stop asking questions.

Graphics were mostly defaults, others by DRK DRAXIS, myself and Brett Bixler.

AIM: TerrorsMartyr
Email: terrorsmartyr@wi.rr.com
Boards: http://www.ironycentral.com/cgi-bin/ubb/ultimatebb.cgi